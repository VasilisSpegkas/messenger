package messenger.login;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import messenger.dao.SqlMethods;
import messenger.users.BasicUser;

public class Login {

	private int dbUserID;
	private String dbUserType;
	
	public Login () {}
	
	//Checking database for credentials inputed by the user
	public String loginUsername(Scanner input) {
		System.out.println("Please enter your username:");
		String inUN = input.next();
		if (inUN.equals("EXIT")) {
			Login.logAllMessages();
			System.out.println("Thank you for using the 'Messenger'...");
			System.out.println("Goodbye!");
			System.exit(0);
		}
		return inUN;
	}
	
	public String loginPassword(Scanner input) {
		System.out.println("Please enter your password:");
		String inPW = input.next();
		if (inPW.equals("EXIT")) {
			Login.logAllMessages();
			System.out.println("Thank you for using the 'Messenger'...");
			System.out.println("Goodbye!");
			System.exit(0);
		}
		return inPW;
	}
	
	public boolean checkPasswordCredentials(BasicUser user) {
		String query = 
				"SELECT DISTINCT user_id,user_name,user_password,user_type FROM users_info "
				+ "WHERE user_name = '" + user.getUserName() + "' AND user_password = '" + user.getPassWord() + "'";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		try {
			while (rs.next()) {
				String dbUserName = rs.getString("user_name");
				String dbUserPassword = rs.getString("user_password");
				this.dbUserID = rs.getInt("user_id");
				this.dbUserType = rs.getString("user_type");
				if (dbUserName.equals(user.getUserName()) && dbUserPassword.equals(user.getPassWord())){
					 System.out.println("Access granted!");
					 System.out.println("Loading User Menu...");
					 return true;
				}
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("Access denied");
		System.out.println("Your information was incorrect. Please try again.");
		return false;
	}
	
	public int getUserID() {
		return dbUserID;
	}
	public String getUserType() {
		return dbUserType;
	}
	
	//Method used to create a txt file to save all messages existing on database
	public static void logAllMessages(){
		String query = "SELECT * FROM inbox;";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		try {
			File file = new File("AllMessagesLogFile.txt");
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file,true);
			BufferedWriter bw = new BufferedWriter(fw);
			System.out.println("Creating backup for messages...");
			String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
			bw.newLine();
			bw.write(String.format("%0" + 55 + "d", 0).replace("0","*"));
			bw.newLine();
			bw.write("MASTER LOG FILE CREATED ON: " + timeStamp);
			bw.newLine();
			bw.write(" ");
			while (rs.next()) { 
				int inbox_id = rs.getInt("inbox_id");
				int receiver = rs.getInt("receiver");
				int sender = rs.getInt("sender");
				String message = rs.getString("message");
				Timestamp timeCreated = rs.getTimestamp("time_info");
				bw.newLine();
				bw.write("Inbox ID: " + inbox_id + "\t" + "\t" + "Timesent: " + timeCreated);
				bw.newLine();
				bw.write("Sender: " + BasicUser.getFullName(sender) + "\t" + "Receiver: " + BasicUser.getFullName(receiver));
				bw.write(message);
				bw.write(String.format("%0" + 55 + "d", 0).replace("0","-"));
			}
			bw.close();
			fw.close();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Backup completed. Messages succesfully saved to file!");
	}
	
}
