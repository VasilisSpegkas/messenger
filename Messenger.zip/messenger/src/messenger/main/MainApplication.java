package messenger.main;

import messenger.menu.Menu;

//Run this class to start application
public class MainApplication {

	public static void main(String[] args) {
	
		Menu.mainMenu();
		
	}
}
