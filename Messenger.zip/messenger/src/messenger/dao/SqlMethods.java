package messenger.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlMethods {

	final static String HOST = "localhost";
	final static String PORT = "3306";
	final static String DRIVER = "jdbc:mysql://";
	final static String DB = "messenger";
	final static String USER = "root";
	final static String PASSWORD = "134561";


	static Connection connection;
	DriverManager dm;
	static Statement stmt = null;

	//							jdbc:mysql://localhost:3306/messenger,root,134561
	//DriverManager.getConnection(DRIVER + HOST + ":" + PORT + "/" + DB, USER, PASSWORD);

	public SqlMethods () {}

	public static java.sql.Connection connect() {
		try {
			connection = DriverManager.getConnection(DRIVER + HOST + ":" + PORT + "/" + DB, USER, PASSWORD);
			return connection;
		}
		catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static ResultSet executeQueryStatement(String query){
		try {
			stmt = connection.createStatement();
			return stmt.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static int executeUpdateStatement(String query){
		try {
			stmt = connection.createStatement();
			return stmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 404;
	}
	
	public static void createDB() {
		executeUpdateStatement("CREATE DATABASE IF NOT EXISTS `messenger`;");
	}

	public static void createUserTable() {
		executeUpdateStatement("CREATE TABLE IF NOT EXISTS  `messenger`.`users_info` (\r\n" + 
				"  `user_id` int(11) NOT NULL AUTO_INCREMENT,\r\n" + 
				"  `first_name` varchar(45) NOT NULL,\r\n" + 
				"  `last_name` varchar(45) NOT NULL,\r\n" + 
				"  `user_name` varchar(45) NOT NULL,\r\n" + 
				"  `user_password` varchar(45) NOT NULL,\r\n" + 
				"  `user_type` varchar(45) NOT NULL,\r\n" + 
				"  PRIMARY KEY (`user_id`),\r\n" + 
				"  UNIQUE KEY `user_name_UNIQUE` (`user_name`)\r\n" + 
				") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1");
	}
	
	public static void createInboxTable() {
		executeUpdateStatement("CREATE TABLE IF NOT EXISTS `inbox` (\r\n" + 
				"  `inbox_id` int(11) NOT NULL AUTO_INCREMENT,\r\n" + 
				"  `receiver` int(11) NOT NULL,\r\n" + 
				"  `sender` int(11) NOT NULL,\r\n" + 
				"  `message` text NOT NULL,\r\n" + 
				"  `time_info` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\r\n" + 
				"  PRIMARY KEY (`inbox_id`),\r\n" + 
				"  KEY `user_user_id_fk_idx` (`receiver`),\r\n" + 
				"  KEY `user_user_id_sender_fk_idx` (`sender`),\r\n" + 
				"  CONSTRAINT `user_user_id_receiver_fk` FOREIGN KEY (`receiver`) REFERENCES `users_info` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,\r\n" + 
				"  CONSTRAINT `user_user_id_sender_fk` FOREIGN KEY (`sender`) REFERENCES `users_info` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE\r\n" + 
				") ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1");
	}
	
	public static void createSuperAdmin() {
		executeUpdateStatement("INSERT INTO users_info (first_name, last_name, user_name, user_password, user_type) \r\n" + 
				"select 'SUPER', 'ADMIN', 'admin', 'admin', 'SUPER_ADMIN'\r\n" + 
				"WHERE not exists (select user_type from users_info where user_type = 'SUPER_ADMIN');");
	}
	
}

