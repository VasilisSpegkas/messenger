package messenger.menu;
import java.sql.SQLException;
import java.util.Scanner;

import messenger.dao.SqlMethods;
import messenger.login.Login;
import messenger.users.AdminUser;
import messenger.users.AdvancedUser;
import messenger.users.BasicUser;
import messenger.users.SuperUser;

public class Menu {

	public static void mainMenu() {
		Scanner input = new Scanner(System.in);
		Login log = new Login();

		try {
			
			//Creating database schema in mySQL if it doesn't exist
			SqlMethods.connect();
			SqlMethods.createDB();
			SqlMethods.createUserTable();
			SqlMethods.createInboxTable();
			SqlMethods.createSuperAdmin();

			//Importing correct menu options depending on user privilleges
			System.out.println("WELCOME TO THE MESSENGER!");
			Login.logAllMessages();
			boolean accessFlag = true;
			while (accessFlag == true){
				System.out.println("\n" + "--------LOGIN MENU--------");
				System.out.println("Please type 'EXIT' any time to close the program!");
				BasicUser u = new BasicUser(log.loginUsername(input),log.loginPassword(input));
				boolean accessFlag2 = (log.checkPasswordCredentials(u));
				while (accessFlag2 == true){
					String userType = log.getUserType();
					switch (userType) {
					case "BASIC":
						BasicUser u1 = new BasicUser();
						String continueChoiceBasicUser = ("Y");
						String BasicUserFullName = BasicUser.getFullName(log.getUserID());
						System.out.print(String.format("%0" + 30 + "d", 0).replace("0","-")+"\n");
						System.out.println("\n" + "Hello " + BasicUserFullName + " !");
						System.out.println("Your privillege status is '" + log.getUserType() + "'.");
						do {
							u1.basicUserMenu();
							String userChoice = input.next();
							switch (userChoice.toUpperCase()) {
							case "1":
								u1.readReceivedMessages(log.getUserID());
								break;
							case "2":
								u1.readMessagesSent(log.getUserID());
								break;
							case "3":
								u1.createMessage(log.getUserID(), input);
								break;
							case "0":
								continueChoiceBasicUser = "0";
								break;
							case "C":
								u1.getContactList();
								break;
							case "EXIT":
								Login.logAllMessages();
								System.out.println("Thank you for using the 'Messenger'...");
								System.out.println("Goodbye!");
								System.exit(0);
								break;
							default:
								System.out.println("Your choice was invalid.");
							}
						}
						while(continueChoiceBasicUser.equalsIgnoreCase("Y"));
						System.out.println("You have logged out!");
						accessFlag2 = false;
						break;
					case "ADVANCED":
						AdvancedUser u2 = new AdvancedUser();
						String continueChoiceAdvancedUser = ("Y");
						String AdvancedUserFullName = BasicUser.getFullName(log.getUserID());
						System.out.print(String.format("%0" + 30 + "d", 0).replace("0","-")+"\n");
						System.out.println("\n" + "Hello " + AdvancedUserFullName);
						System.out.println("Your privillege status is '" + log.getUserType() + "'.");
						do {
							u2.advancedUserMenu();
							String userChoice = input.next();
							switch (userChoice.toUpperCase()) {
							case "1":
								u2.readReceivedMessages(log.getUserID());
								break;
							case "2":
								u2.readMessagesSent(log.getUserID());
								break;
							case "3":
								u2.createMessage(log.getUserID(), input);
								break;
							case "4":
								u2.updatePassword(log.getUserID(), input);
								break;
							case "5":
								u2.updateMessage();
								break;
							case "6":
								u2.readAllMessages();
								break;
							case "0":
								continueChoiceAdvancedUser = "0";
								break;
							case "C":
								u2.getContactList();
								break;
							case "EXIT":
								Login.logAllMessages();
								System.out.println("Thank you for using the 'Messenger'...");
								System.out.println("Goodbye!");
								System.exit(0);
								break;
							default:
								System.out.println("Your choice was invalid.");
							}
						}
						while(continueChoiceAdvancedUser.equalsIgnoreCase("Y"));
						System.out.println("You have logged out!");
						accessFlag2 = false;
						break;	
					case "SUPER":
						SuperUser u3 = new SuperUser();
						String continueChoiceSuperUser = ("Y");
						String SuperUserFullName = BasicUser.getFullName(log.getUserID());
						System.out.print(String.format("%0" + 30 + "d", 0).replace("0","-")+"\n");
						System.out.println("\n" + "Hello " + SuperUserFullName);
						System.out.println("Your privillege status is '" + log.getUserType() + "'.");
						do {
							u3.superUserMenu();
							String userChoice = input.next();
							switch (userChoice.toUpperCase()) {
							case "1":
								u3.readReceivedMessages(log.getUserID());
								break;
							case "2":
								u3.readMessagesSent(log.getUserID());
								break;
							case "3":
								u3.createMessage(log.getUserID(), input);
								break;
							case "4":
								u3.updatePassword(log.getUserID(), input);
								break;
							case "5":
								u3.updateMessage();
								break;
							case "6":
								u3.readAllMessages();
								break;
							case "7":
								u3.deleteMessage(input);
								break;
							case "0":
								continueChoiceSuperUser = "0";
								break;
							case "LOG":
								u3.logUserMessages(input);
								break;
							case "C":
								u3.getContactList();
								break;
							case "EXIT":
								Login.logAllMessages();
								System.out.println("Thank you for using the 'Messenger'...");
								System.out.println("Goodbye!");
								System.exit(0);
								break;
							default:
								System.out.println("Your choice was invalid.");
							}
						}
						while(continueChoiceSuperUser.equalsIgnoreCase("Y"));
						System.out.println("You have logged out!");
						accessFlag2 = false;
						break;
					case "ADMIN":
					case "SUPER_ADMIN":
						AdminUser u4 = new AdminUser();
						String continueChoiceAdmin = ("Y");
						String AdminFullName = BasicUser.getFullName(log.getUserID());
						System.out.print(String.format("%0" + 30 + "d", 0).replace("0","-")+"\n");
						System.out.println("\n" + "Hello " + AdminFullName);
						System.out.println("Your privillege status is '" + log.getUserType() + "'.");
						do {
							u4.adminUserMenu();
							String userChoice = input.next();
							switch (userChoice.toUpperCase()) {
							case "1":
								u4.readReceivedMessages(log.getUserID());
								break;
							case "2":
								u4.readMessagesSent(log.getUserID());
								break;
							case "3":
								u4.createMessage(log.getUserID(), input);
								break;
							case "4":
								u4.updatePassword(log.getUserID(), input);
								break;
							case "5":
								u4.updateMessage();
								break;
							case "6":
								u4.readAllMessages();
								break;
							case "7":
								u4.deleteMessage(input);
								break;
							case "8":
								u4.createNewUser(input);
								break;
							case "9":
								u4.deleteUser(input);
								break;
							case "0":
								continueChoiceAdmin = "0";
								break;
							case "LOG":
								u4.logUserMessages(input);
								break;
							case "C":
								u4.getCompleteContactList();
								break;
							case "EXIT":
								Login.logAllMessages();
								System.out.println("Thank you for using the 'Messenger'...");
								System.out.println("Goodbye!");
								System.exit(0);
								break;
							default:
								System.out.println("Your choice was invalid.");
							}
						}
						while(continueChoiceAdmin.equalsIgnoreCase("Y"));
						System.out.println("You have logged out!");
						accessFlag2 = false;
						break;
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error found! Closing the 'Messenger'.");
			Login.logAllMessages();
			System.out.println("Goodbye!");
		}
		finally {
			if (SqlMethods.connect() != null) {
				try {
					SqlMethods.connect().close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		input.close();
	}
}
