package messenger.users;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import messenger.dao.SqlMethods;

public class SuperUser extends AdvancedUser{

	public SuperUser () {}

	public void superUserMenu() {
		System.out.println("\n" + "------USER MENU------");
		System.out.println("Press 1 to read received messages.");
		System.out.println("Press 2 to read sent messages.");
		System.out.println("Press 3 to create and send a message.");
		System.out.println("Press 4 to update your password.");
		System.out.println("Press 5 to update a message.");
		System.out.println("Press 6 to read all messages.");
		System.out.println("Press 7 to delete a message.");
		System.out.println("Press 0 to Log out.");
		System.out.println("Type 'LOG' to create a log message file for a specific user.");
		System.out.println("Type 'C' to see the contact list.");
	}

	public void deleteMessage(Scanner input) {
		String queryInboxALL = "SELECT * FROM inbox;";
		ResultSet rs = SqlMethods.executeQueryStatement(queryInboxALL);
		try {
			while (rs.next()) {
				int inbox_id = rs.getInt("inbox_id");
				int receiver = rs.getInt("receiver");
				int sender = rs.getInt("sender");
				String message = rs.getString("message");
				Timestamp timeCreated= rs.getTimestamp("time_info");
				System.out.println("Message with Inbox ID number: " + inbox_id);
				System.out.println(getFullName(sender) + " sent to " + getFullName(receiver) + " on " + timeCreated + " the following message:");
				System.out.println(message);
				System.out.println("----End message----" + "\n");
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			System.out.println("Please enter the message's 'Inbox ID number' that you want to delete.");
			int inbox_id = input.nextInt();
			String queryMsgDEL = "DELETE FROM inbox WHERE inbox_id = " + inbox_id +";";
			SqlMethods.executeUpdateStatement(queryMsgDEL);
			System.out.println("Message deleted");
		}
		catch (java.util.InputMismatchException ex){
			System.out.println("Wrong input. Please try again.");
		}
	}

	public void logUserMessages(Scanner input){
		getContactList();
		try {
			System.out.println("Please enter the 'User ID' you want to create a log for:");
			int userID = input.nextInt();
			String query = "SELECT * FROM inbox WHERE inbox.receiver = " + userID + " OR inbox.sender = " + userID + ";";
			ResultSet rs = SqlMethods.executeQueryStatement(query);
			File file = new File(getFullName(userID) + "_MessagesLogFile.txt");
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file,true);
			BufferedWriter bw = new BufferedWriter(fw);
			System.out.println("Creating backup for messages...");
			String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
			bw.newLine();
			bw.write(String.format("%0" + 55 + "d", 0).replace("0","*"));
			bw.newLine();
			bw.write("LOG FILE CREATED ON: " + timeStamp);
			bw.newLine();
			bw.write(" ");
			while (rs.next()) { 
				int inbox_id = rs.getInt("inbox_id");
				int receiver = rs.getInt("receiver");
				int sender = rs.getInt("sender");
				String message = rs.getString("message");
				Timestamp timeCreated = rs.getTimestamp("time_info");
				bw.newLine();
				bw.write("Inbox ID: " + inbox_id + "\t" + "\t" + "Timesent: " + timeCreated);
				bw.newLine();
				bw.write("Sender: " + BasicUser.getFullName(sender) + "\t" + "Receiver: " + BasicUser.getFullName(receiver));
				bw.write(message);
				bw.write(String.format("%0" + 55 + "d", 0).replace("0","-"));
			}
			bw.close();
			fw.close();
		}
		catch (java.util.InputMismatchException ex) {
			System.out.println("Wrong input. User ID must be a number. Please try again.");
		}
		catch (Exception e){
			e.printStackTrace();
		}
		System.out.println("Backup completed. Messages succesfully saved to file!");
	}

}
