package messenger.users;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import messenger.dao.SqlMethods;

//Menu for user with Admin privilleges
public class AdminUser extends SuperUser{

	String newUsersPrivileges;
	
	public AdminUser () {}
	
	public void adminUserMenu() {
		System.out.println("\n" + "------USER MENU------");
		System.out.println("Press 1 to read received messages.");
		System.out.println("Press 2 to read sent messages.");
		System.out.println("Press 3 to create and send a message.");
		System.out.println("Press 4 to update your password.");
		System.out.println("Press 5 to update a message.");
		System.out.println("Press 6 to read all messages.");
		System.out.println("Press 7 to delete a message.");
		System.out.println("Press 8 to create a new user.");
		System.out.println("Press 9 to delete a user.");
		System.out.println("Press 0 to Log out.");
		System.out.println("Type 'LOG' to create a log message file for a specific user.");
		System.out.println("Type 'C' to see the complete users information list.");
	}
	
	//Method to create a new User
	public void createNewUser(Scanner input) {
		System.out.println("Please enter the new users 'first name':");
		String newUsersFirstName = input.next().toUpperCase();
		System.out.println("Please enter the new users 'surname':");
		String newUsersSurname = input.next().toUpperCase();
		System.out.println("Please enter the new users 'user name':");
		String newUsersUserName = input.next();
		System.out.println("Please enter the new users 'password':");
		String newUsersPassword = input.next();
		System.out.println("Please assign the new user's privileges:");
		System.out.println("Press 1 for 'BASIC'.");
		System.out.println("Press 2 for 'ADVANCED'.");
		System.out.println("Press 3 for 'SUPER'.");
		System.out.println("Press 4 for 'ADMIN'.");
		int privilegeSelection = input.nextInt();
		if (privilegeSelection == 1) {
			this.newUsersPrivileges = "BASIC";
		}
		else if (privilegeSelection == 2){
			this.newUsersPrivileges = "ADVANCED";
		}
		else if (privilegeSelection == 3) {
			this.newUsersPrivileges = "SUPER";
		}
		else if (privilegeSelection == 4) {
			this.newUsersPrivileges = "ADMIN";
		}
		else {
			System.out.println("Wrong selection. Please try again.");
		}
		System.out.println("Do you want to create a new user with the following information:");
		System.out.println("First name: " + newUsersFirstName);
		System.out.println("Surname: " + newUsersSurname);
		System.out.println("User name: " + newUsersUserName);
		System.out.println("Password: " + newUsersPassword);
		System.out.println("User type: " + newUsersPrivileges);
		System.out.println("Press 'Y' to CREATE or any key to dismiss this user.");
		String newUserCreation = input.next();
		if (newUserCreation.equalsIgnoreCase("Y")) {
			try {
				PreparedStatement stmt;
				stmt = SqlMethods.connect().prepareStatement("INSERT INTO users_info "
						+ "(first_name,last_name,user_name,user_password,user_type) VALUES (?,?,?,?,?);");
				stmt.setString(1,newUsersFirstName);
				stmt.setString(2,newUsersSurname);
				stmt.setString(3,newUsersUserName);
				stmt.setString(4,newUsersPassword);
				stmt.setString(5,newUsersPrivileges);
				stmt.executeUpdate();
				System.out.println("New user created.");
			} catch (SQLException e) {
				System.out.println("Password is already used. Please try again using a different one.");
			}
		}
		else {
			System.out.println("User discarded. No changes were made.");
		}
	}
	
	//Method to delete an existing user
	public void deleteUser(Scanner input) {
		getContactList();
		try {
			System.out.println("Please enter the 'User's ID number' that you want to delete.");
			int user_id = input.nextInt();
			String queryMsgDEL = "DELETE FROM users_info WHERE user_id = " + user_id + ";";
			int result = SqlMethods.executeUpdateStatement(queryMsgDEL);
			if (result == 0) {
				System.out.println("User does not exist! Please try again.");
			}
			else {
				System.out.println("User deleted");
			}
		} catch (java.util.InputMismatchException Mismatch) {
			System.out.println("This is not a valid 'User ID number'.Please try again.");
		}
	}
	
	//Method to get the ALL the information of existing users from the database table (including passwords)
	public void getCompleteContactList() {
		String query = "SELECT * FROM users_info;";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		System.out.println("MESSENGER USERS INFORMATION:");
		System.out.printf("%-10s %-15s %-15s %-15s %-15s %s %n","USER ID","FIRST NAME","LAST NAME","USER NAME","USER PASSWORD","USER TYPE");
		System.out.print(String.format("%0" + 100 + "d", 0).replace("0","-")+"\n");
		try {
			while (rs.next()) {
				int user_id = rs.getInt("user_id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String userName = rs.getString("user_name");
				String userPassword = rs.getString("user_password");
				String userType = rs.getString("user_type");
				System.out.printf("%-10s %-15s %-15s %-15s %-15s %s %n",user_id,firstName,lastName,userName,userPassword,userType);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
