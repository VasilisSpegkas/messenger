package messenger.users;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;

import messenger.dao.SqlMethods;

public class BasicUser {

	private String userName;
	private String passWord;

	public BasicUser() {}

	public BasicUser(String un, String pw) {
		this.userName = un;
		this.passWord = pw;
	}
	
	public void basicUserMenu() {
		System.out.println("\n" + "------USER MENU------");
		System.out.println("Press 1 to read received messages.");
		System.out.println("Press 2 to read sent messages.");
		System.out.println("Press 3 to create and send a message.");
		System.out.println("Press 0 to Log out.");
		System.out.println("Type 'C' to see the contact list.");
	}
	
	//Method that prints all messages received from the user
	public void readReceivedMessages(int userID) {
		String query = "SELECT message,sender,time_info FROM inbox WHERE inbox.receiver =" + userID + ";";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		try {
			if (rs.next() == false) {
				System.out.println("No message found.");
			}
			else {
				do {
					int sender = rs.getInt("sender");
					Timestamp timeCreated = rs.getTimestamp("time_info");
					String message = rs.getString("message");
					System.out.println(getFullName(sender) + " sent on " + timeCreated + " the following message:");
					System.out.println(message);
					System.out.println("----End message----" + "\n");
				} while (rs.next());
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//Method that prints all messages sent from the user
	public void readMessagesSent(int userID) {
		String query = "SELECT message,time_info,receiver FROM inbox WHERE sender = " + userID + " ;";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		try {
			if (rs.next() == false) {
				System.out.println("No message found.");
			}
			else {
				do {
					int receiverID = rs.getInt("receiver");
					String message = rs.getString("message");
					Timestamp timeCreated= rs.getTimestamp("time_info");
					System.out.println("You sent to : " + getFullName(receiverID) + " on " + timeCreated + " the following message:");
					System.out.println(message);
					System.out.println("----End message----" + "\n");
				} while (rs.next());
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//Helping method that gets 'first_name' and 'last_name' of a user using the 'user_id' column
	public static String getFullName(int num) {
		String query = "SELECT first_name,last_name FROM users_info WHERE users_info.user_id =" + num + ";";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		try {
			while (rs.next()) {
				String userFirstName = rs.getString("first_name");
				String userLastName = rs.getString("last_name");
				return userFirstName + " " +  userLastName;
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return "No user found";
	}

	//Method to get the users 'last_name', 'first_name' and 'user_id' information
	public void getContactList() {
		String query = "SELECT user_id,first_name,last_name FROM users_info;";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		System.out.println("MESSENGER CONTACT LIST:");
		System.out.printf("%-15s%-15s%s%n","Last name","First name","User ID");
		System.out.print(String.format("%0" + 40 + "d", 0).replace("0","-")+"\n");
		try {
			while (rs.next()) {
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				int user_ID = rs.getInt("user_id"); 
				System.out.printf("%-15s%-15s%s%n",lastName,firstName,user_ID);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//Method to create and send a message.
	//To stop typing and send your message type ' EndMsg ' and hit enter on the console.
	public void createMessage(int userID, Scanner input) {
		getContactList();
		try {
			System.out.println("Please enter the receiver's 'User ID':");
			String receiverID = input.next();
			Integer.parseInt(receiverID);
			System.out.println("Please type in your message:");
			String message = input.useDelimiter("EndMsg").next();
			String query = 
					"INSERT INTO inbox"
							+ "(message,sender,receiver)"
							+ "VALUES ('" + message + "'," + userID + "," + receiverID + ");";
			SqlMethods.executeUpdateStatement(query);
			System.out.println("Message created and sent");
		}
		catch (java.lang.NumberFormatException e) {
			System.out.println("Invalid number. Please try again.");
		}
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

}
