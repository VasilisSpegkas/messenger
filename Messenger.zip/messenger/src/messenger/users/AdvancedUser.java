package messenger.users;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;

import messenger.dao.SqlMethods;

public class AdvancedUser extends BasicUser{

	public AdvancedUser () {}

	public void advancedUserMenu() {
		System.out.println("\n" + "------USER MENU------");
		System.out.println("Press 1 to read received messages.");
		System.out.println("Press 2 to read sent messages.");
		System.out.println("Press 3 to create and send a message.");
		System.out.println("Press 4 to update your password.");
		System.out.println("Press 5 to update a message.");
		System.out.println("Press 6 to read all messages.");
		System.out.println("Press 0 to Log out.");
		System.out.println("Type 'C' to see the contact list.");
	}
	
	public void updatePassword(int userID, Scanner input) {
		String choice = "Y";
		do {
			System.out.println("Please enter your new password.");
			String newPassword1 = input.next();
			System.out.println("Please re-enter you new password.");
			String newPassword2 = input.next();
			if (newPassword1.equals(newPassword2)) {
				String query = 
						"UPDATE users_info SET user_password = '" + newPassword1 + "' WHERE user_id = " + userID + " ;";
				SqlMethods.executeUpdateStatement(query);
				System.out.println("Password succesfully updated!");
				break;
			}
			else {
				System.out.println("Passwords do not match!");
				System.out.println("Do you want to try again? (Y/N)");
				choice = input.next();
			}
		}while(choice.equalsIgnoreCase("Y"));
	}

	public void updateMessage() {
		Scanner input = new Scanner(System.in);
		try {
			String updateMessageChoice = "N";
			do {
				getInboxList();
				System.out.println("Please enter the message's 'inboxID' number you want to edit:");
				int inboxIDtoEdit = input.nextInt();
				String query = "SELECT * FROM inbox WHERE inbox_id = " + inboxIDtoEdit + " ;";
				ResultSet rs = SqlMethods.executeQueryStatement(query);
				if (!rs.isBeforeFirst() ) {    
					System.out.println("The 'Inbox ID' number you have entered is wrong."); 
				} 
				else {
					while (rs.next()) {
						int inbox_id = rs.getInt("inbox_id");
						int receiver = rs.getInt("receiver");
						int sender = rs.getInt("sender");
						String message = rs.getString("message");
						Timestamp timeCreated= rs.getTimestamp("time_info");
						System.out.println("Current message with Inbox ID number: " + inbox_id);
						System.out.println(getFullName(sender) + " sent to " + getFullName(receiver) + " on " + timeCreated + " the following message:");
						System.out.println(message);
						System.out.println("----End message----" + "\n");
						System.out.println("Is this the message you want to update? (Y/N)");
						updateMessageChoice = input.next();
						if (updateMessageChoice.equalsIgnoreCase("Y")) {
							System.out.println("Please type in the new message.");
							String editedMessage = input.useDelimiter("EndMsg").next();
							PreparedStatement stmt;
							stmt = SqlMethods.connect().prepareStatement(
									"UPDATE inbox SET message = ? WHERE inbox_id = ?;");
							stmt.setString(1, editedMessage);
							stmt.setInt(2, inboxIDtoEdit);
							stmt.executeUpdate();
							System.out.println("Message succesfully updated!");
							break;
						}
					}
				}
			}while (updateMessageChoice.equalsIgnoreCase("N"));
		}
		catch (SQLException e) {
			e.printStackTrace(); 
		}
	}

	public void getInboxList() {
		String query = "SELECT * FROM messenger.inbox;";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		System.out.println("MESSENGER CONTACT LIST:");
		System.out.printf("%-12s %-23s %-23s %s %n","INBOX ID","SENDER","RECEIVER","DATE/TIME SENT");
		System.out.print(String.format("%0" + 80 + "d", 0).replace("0","-")+"\n");
		try {
			while (rs.next()) {
				int inbox_id = rs.getInt("inbox_id");
				int receiver = rs.getInt("receiver");
				int sender = rs.getInt("sender");
				Timestamp timeCreated= rs.getTimestamp("time_info");
				System.out.printf("%-12s%-23s%-23s%s%n",inbox_id, getFullName(sender), getFullName(receiver), timeCreated);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void readAllMessages() {
		String query = "SELECT * FROM inbox;";
		ResultSet rs = SqlMethods.executeQueryStatement(query);
		try {
			if (rs.next() == false) {
				System.out.println("No message found.");
			}
			else {
				do {
					int inbox_id = rs.getInt("inbox_id");
					int receiver = rs.getInt("receiver");
					int sender = rs.getInt("sender");
					String message = rs.getString("message");
					Timestamp timeCreated = rs.getTimestamp("time_info");
					System.out.println("Message with Inbox ID: " + inbox_id);
					System.out.println("'" + getFullName(sender) + "' sent to '" + getFullName(receiver) + " on " + timeCreated + " the following message:");
					System.out.println(message);
					System.out.println("----End message----" + "\n");
				} while (rs.next());
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
